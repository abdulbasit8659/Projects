
#Regional Inequalities in Expenditure

# Load necessary libraries
library(ggplot2)
library(dplyr)
library(ineq)  
library(sf)    

regional_data <- read.csv("D:/New folder/Project 1 (10K)/AppQE_TS_project_01.csv")
head(regional_data)



# Main dataset
data <- data.frame(
  Year = c("1999_00", "2000_01", "2001_02", "2002_03", "2003_04", "2004_05",
           "2005_06", "2006_07", "2007_08", "2008_09", "2009_10", "2010_11",
           "2011_12", "2012_13", "2013_14", "2014_15", "2015_16", "2016_17"),
  Total.Gross.Expenditure = c(9021.39, 10144.32, 11267.26, 11329.02, 12556.79,
                              13476.38, 14474.68, 15206.80, 16008.64, 16656.01,
                              16777.74, 16485.46, 12658.75, 9662.38, 8266.46,
                              7495.87, 6836.26, 6357.19),
  Total.Funding = c(8394.53, 9439.44, 10484.35, 10541.82, 11924.98, 12752.00,
                    13555.58, 14295.03, 15148.43, 15510.54, 15660.77, 15565.03,
                    12128.44, 9257.26, 7901.44, 7020.86, 6445.39, 5902.49),
  GDP.Deflator = c(71.25, 72.73, 73.62, 75.34, 76.99, 79.14, 81.20, 83.74,
                   85.82, 88.06, 89.34, 90.97, 92.28, 94.19, 95.80, 97.19,
                   97.85, 100.00)
)


regional_data <- data.frame(
  Region = c("Region1", "Region2", "Region3", "Region1", "Region2", "Region3"),
  Year = c("1999_00", "1999_00", "1999_00", "2000_01", "2000_01", "2000_01"),
  Total.Expenditure = c(3000, 4000, 2021.39, 3500, 5000, 2644.32),
  Total.Students = c(500, 600, 400, 550, 650, 450)
)
summary(regional_data)
# Calculate per-pupil expenditure
regional_data <- regional_data %>%
  mutate(per_pupil_expenditure = Total.Expenditure / Total.Students)

# Calculate mean per-pupil expenditure by region
mean_expenditure_by_region <- regional_data %>%
  group_by(Region) %>%
  summarise(mean_per_pupil_expenditure = mean(per_pupil_expenditure))

# Plotting regional differences
ggplot(mean_expenditure_by_region, aes(x = Region, y = mean_per_pupil_expenditure)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  theme_minimal() +
  labs(title = "Mean Per-Pupil Expenditure by Region",
       x = "Region", y = "Mean Per-Pupil Expenditure (£)")




#Calculate Per-Pupil Expenditure

# Simulate number of pupils
regional_data <- regional_data %>%
  mutate(Pupils = runif(n = nrow(regional_data), min = 1000, max = 3000))

# Calculate per-pupil expenditure
regional_data <- regional_data %>%
  mutate(per_pupil_expenditure = Total.Expenditure / Pupils)

summary(regional_data)



# Quantify Inequality Using Gini Coefficient

library(ineq)


# Calculate Gini coefficient for each year
gini_by_year <- regional_data %>%
  group_by(Year) %>%
  summarise(gini = ineq(per_pupil_expenditure, type = "Gini"))

# Plot Gini coefficient over time
ggplot(gini_by_year, aes(x = Year, y = gini)) +
  geom_line(color = "blue") +
  geom_point(color = "red") +
  theme_minimal() +
  labs(title = "Gini Coefficient of Per-Pupil Expenditure Over Time",
       x = "Year", y = "Gini Coefficient")



# Box plot of per-pupil expenditure by region
ggplot(data_with_regions, aes(x = factor(Year), y = per_pupil_expenditure, fill = Region)) +
  geom_boxplot() +
  theme_minimal() +
  labs(title = "Per-Pupil Expenditure by Region Over Time",
       x = "Year", y = "Per-Pupil Expenditure (£, 2016/17 prices)")



# 2.	Question 2 Evolution of Total Gross Expenditure 
library(ggplot2)
library(dplyr)

# Load your data
data <- read.csv("path_to_data.csv")

# Adjust expenditures for inflation
data <- data %>%
  mutate(real_expenditure = Total.Gross.Expenditure / (GDP.deflator / 100))

# Plotting the real expenditure over time
ggplot(data, aes(x = Year, y = real_expenditure)) +
  geom_line() +
  geom_smooth(method = "lm", col = "blue") +
  theme_minimal() +
  labs(title = "Real Total Gross Expenditure Over Time",
       x = "Year", y = "Expenditure (£ million, 2016/17 prices)")




# Question 3: Determinants of Secondary School Expenditure


library(dplyr)
library(ggplot2)

determinants_data <- read.csv("path_to_determinants_data.csv")


combined_data <- left_join(data, determinants_data, by = "Year")

# Performing multiple regression analysis
model <- lm(real_expenditure ~ Total.Funding + school_size + personalized_teaching + location, data = combined_data)
summary(model)

# Plotting residuals to check assumptions
plot(model)











