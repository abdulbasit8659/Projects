#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int readNumOfCoords(char *filename) {
    FILE *file = fopen(filename, "r");
    int numOfCoords = 0;

    if (file == NULL) {
        return -1;
    }

    char line[100];
    while (fgets(line, sizeof(line), file) != NULL) {
        numOfCoords++;
    }

    fclose(file);
    return numOfCoords;
}


double** readCoords(char *filename, int numOfCoords) {
    FILE *file = fopen(filename, "r");
    int i;
    double **coords;

    if (file == NULL) {
        printf("Unable to open file: %s\n", filename);
        return NULL;
    }

    coords = (double **)malloc(numOfCoords * sizeof(double *));
    for (i = 0; i < numOfCoords; i++) {
        coords[i] = (double *)malloc(2 * sizeof(double));
    }

    int lineNum = 0;
    char line[100];
    while (fgets(line, sizeof(line), file) != NULL) {
        sscanf(line, "%lf,%lf", &coords[lineNum][0], &coords[lineNum][1]);
        lineNum++;
    }

    fclose(file);
    return coords;
}

double euclideanDistance(double x1, double y1, double x2, double y2) {
    return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
}


double** createDistanceMatrix(double **coords, int numOfCoords) {
    int i, j;
    double **distMatrix;

    distMatrix = (double **)malloc(numOfCoords * sizeof(double *));
    for (i = 0; i < numOfCoords; i++) {
        distMatrix[i] = (double *)malloc(numOfCoords * sizeof(double));
    }

    for (i = 0; i < numOfCoords; i++) {
        for (j = 0; j < numOfCoords; j++) {
            if (i == j) {
                distMatrix[i][j] = 0;
            } else {
                distMatrix[i][j] = euclideanDistance(coords[i][0], coords[i][1], coords[j][0], coords[j][1]);
            }
        }
    }

    return distMatrix;
}

// Main function
int main() {
    char *filename = "4096_coords.txt";
    int numOfCoords = readNumOfCoords(filename);
    if (numOfCoords == -1) {
        printf("Error reading the file.\n");
        return 1;
    }

    double **coords = readCoords(filename, numOfCoords);
    if (coords == NULL) {
        return 1;
    }

    double **distMatrix = createDistanceMatrix(coords, numOfCoords);

    
    int i, j;
    for (i = 0; i < numOfCoords; i++) {
        for (j = 0; j < numOfCoords; j++) {
            printf("%.2f ", distMatrix[i][j]);
        }
        printf("\n");
    }


    for (i = 0; i < numOfCoords; i++) {
        free(coords[i]);
        free(distMatrix[i]);
    }
    free(coords);
    free(distMatrix);

    return 0;
}
