#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include <stdbool.h>

// Function declarations
int readNumOfCoords(const char *fileName);
double **readCoords(const char *filename, int numOfCoords);
void printTourToTerminal(const int *tour, int tourLength);
double **createDistanceMatrix(double **coords, int numOfCoords);
int findNextVertexMinMax(const int *tour, int tourLength, double **distanceMatrix, int numOfCoords, const bool *visited);
int findBestInsertionPosition(const int *tour, int tourLength, int nextVertex, double **distanceMatrix);

// Main function
int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <coordinate file>\n", argv[0]);
        return 1;
    }

    char *inputFile = "mmout4096.dat";

    // Read coordinates
    int numOfCoords = readNumOfCoords(inputFile);
    if (numOfCoords <= 0) {
        printf("Error reading number of coordinates.\n");
        return 1;
    }

    double **coords = readCoords(inputFile, numOfCoords);
    if (coords == NULL) {
        printf("Error reading coordinates.\n");
        return 1;
    }

    // Create distance matrix
    double **distanceMatrix = createDistanceMatrix(coords, numOfCoords);

    // MinMax Insertion algorithm
    int *tour = (int *)malloc(numOfCoords * sizeof(int));
    bool *visited = (bool *)malloc(numOfCoords * sizeof(bool));
    if (tour == NULL || visited == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    for (int i = 0; i < numOfCoords; i++) {
        visited[i] = false;
    }

    // Start with the vertex with the lowest index
    tour[0] = 0;
    visited[0] = true;
    int tourLength = 1;

    while (tourLength < numOfCoords) {
        int nextVertex = findNextVertexMinMax(tour, tourLength, distanceMatrix, numOfCoords, visited);
        if (nextVertex == -1) {
            printf("No valid next vertex found.\n");
            break;
        }
        int bestPosition = findBestInsertionPosition(tour, tourLength, nextVertex, distanceMatrix);

        // Insert the next vertex at the best position
        for (int i = tourLength; i > bestPosition; i--) {
            tour[i] = tour[i - 1];
        }
        tour[bestPosition] = nextVertex;
        visited[nextVertex] = true;
        tourLength++;
    }

    // Print tour to terminal
    printTourToTerminal(tour, tourLength);

    // Free allocated memory
    for (int i = 0; i < numOfCoords; i++) {
        free(coords[i]);
        free(distanceMatrix[i]);
    }
    free(coords);
    free(distanceMatrix);
    free(tour);
    free(visited);

    return 0;
}

// Function to create the distance matrix
double **createDistanceMatrix(double **coords, int numOfCoords) {
    double **distanceMatrix = (double **)malloc(numOfCoords * sizeof(double *));
    for (int i = 0; i < numOfCoords; i++) {
        distanceMatrix[i] = (double *)malloc(numOfCoords * sizeof(double));
        for (int j = 0; j < numOfCoords; j++) {
            double dx = coords[i][0] - coords[j][0];
            double dy = coords[i][1] - coords[j][1];
            distanceMatrix[i][j] = sqrt(dx * dx + dy * dy);
        }
    }
    return distanceMatrix;
}

// Function to find the next vertex using the MinMax criterion
int findNextVertexMinMax(const int *tour, int tourLength, double **distanceMatrix, int numOfCoords, const bool *visited) {
    int nextVertex = -1;
    double minMaxDistance = INT_MAX;

    for (int i = 0; i < numOfCoords; i++) {
        if (!visited[i]) {
            double maxDistance = 0;
            for (int j = 0; j < tourLength; j++) {
                double distance = distanceMatrix[i][tour[j]];
                if (distance > maxDistance) {
                    maxDistance = distance;
                }
            }
            if (maxDistance < minMaxDistance) {
                minMaxDistance = maxDistance;
                nextVertex = i;
            }
        }
    }
    return nextVertex;
}

// Function to find the best insertion position
int findBestInsertionPosition(const int *tour, int tourLength, int nextVertex, double **distanceMatrix) {
    int bestPosition = 0;
    double minIncrease = INT_MAX;

    for (int i = 0; i < tourLength; i++) {
        int j = (i + 1) % tourLength;
        double increase = distanceMatrix[tour[i]][nextVertex] + distanceMatrix[nextVertex][tour[j]] - distanceMatrix[tour[i]][tour[j]];
        if (increase < minIncrease) {
            minIncrease = increase;
            bestPosition = i + 1;
        }
    }
    return bestPosition;
}

// Function to read the number of coordinates from file
int readNumOfCoords(const char *filename) {
    FILE *file = fopen(filename, "r");
    int numOfCoords = 0;

    if (file == NULL) {
        printf("Unable to open file: %s\n", filename);
        return -1;
    }

    if (fscanf(file, "%d", &numOfCoords) != 1) {
        printf("Failed to read the number of coordinates.\n");
        fclose(file);
        return -1;
    }

    fclose(file);
    return numOfCoords;
}

// Function to read coordinates from file
double **readCoords(const char *filename, int numOfCoords) {
    FILE *file = fopen(filename, "r");
    int i;
    double **coords;

    if (file == NULL) {
        printf("Unable to open file: %s\n", filename);
        return NULL;
    }

    coords = (double **)malloc(numOfCoords * sizeof(double *));
    for (i = 0; i < numOfCoords; i++) {
        coords[i] = (double *)malloc(2 * sizeof(double));
    }

    if (fscanf(file, "%*d") != 0) { // Read and ignore the number of coordinates
        printf("Failed to skip the number of coordinates.\n");
        fclose(file);
        return NULL;
    }

    for (i = 0; i < numOfCoords; i++) {
        if (fscanf(file, "%lf %lf", &coords[i][0], &coords[i][1]) != 2) {
            printf("Failed to read coordinates at index %d.\n", i);
            for (int j = 0; j <= i; j++) {
                free(coords[j]);
            }
            free(coords);
            fclose(file);
            return NULL;
        }
    }

    fclose(file);
    return coords;
}

// Function to print the tour to the terminal
void printTourToTerminal(const int *tour, int tourLength) {
    printf("Tour:\n");
    for (int i = 0; i < tourLength; i++) {
        printf("%d\n", tour[i]);
    }
}
