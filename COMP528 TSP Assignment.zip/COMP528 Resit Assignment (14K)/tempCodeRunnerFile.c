#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include <stdbool.h>
#include <omp.h>

// Function declarations
int readNumOfCoords(char *fileName);
double **readCoords(char *filename, int numOfCoords);
double **createDistanceMatrix(double **coords, int numOfCoords);
int findNextVertexMinMax(int *tour, int tourLength, double **distanceMatrix, int numOfCoords, bool *visited);
int findBestInsertionPosition(int *tour, int tourLength, int nextVertex, double **distanceMatrix);

// Main function
int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <coordinate file> <output file>\n", argv[0]);
        return 1;
    }

    char *inputFile = argv[1];
    char *outputFile = argv[2];

    // Read coordinates
    int numOfCoords = readNumOfCoords(inputFile);
    double **coords = readCoords(inputFile, numOfCoords);

    // Create distance matrix
    double **distanceMatrix = createDistanceMatrix(coords, numOfCoords);

    // MinMax Insertion algorithm
    int *tour = (int *)malloc(numOfCoords * sizeof(int));
    bool *visited = (bool *)malloc(numOfCoords * sizeof(bool));
    for (int i = 0; i < numOfCoords; i++) {
        visited[i] = false;
    }

    // Start with the vertex with the lowest index
    tour[0] = 0;
    visited[0] = true;
    int tourLength = 1;

    // Start timing the execution
    double start_time, end_time;
    start_time = omp_get_wtime();

    while (tourLength < numOfCoords) {
        int nextVertex = findNextVertexMinMax(tour, tourLength, distanceMatrix, numOfCoords, visited);
        int bestPosition = findBestInsertionPosition(tour, tourLength, nextVertex, distanceMatrix);

        // Insert the next vertex at the best position
        for (int i = tourLength; i > bestPosition; i--) {
            tour[i] = tour[i - 1];
        }
        tour[bestPosition] = nextVertex;
        visited[nextVertex] = true;
        tourLength++;
    }

    // Stop timing the execution
    end_time = omp_get_wtime();
    printf("Execution time: %f seconds\n", end_time - start_time);

    // Print the tour to the terminal
    for (int i = 0; i < tourLength; i++) {
        printf("%d\n", tour[i]);
    }

    // Free allocated memory
    for (int i = 0; i < numOfCoords; i++) {
        free(coords[i]);
        free(distanceMatrix[i]);
    }
    free(coords);
    free(distanceMatrix);
    free(tour);
    free(visited);

    return 0;
}

// Function to create the distance matrix with OpenMP parallelization
double **createDistanceMatrix(double **coords, int numOfCoords) {
    double **distanceMatrix = (double **)malloc(numOfCoords * sizeof(double *));
    #pragma omp parallel for
    for (int i = 0; i < numOfCoords; i++) {
        distanceMatrix[i] = (double *)malloc(numOfCoords * sizeof(double));
        for (int j = 0; j < numOfCoords; j++) {
            double dx = coords[i][0] - coords[j][0];
            double dy = coords[i][1] - coords[j][1];
            distanceMatrix[i][j] = sqrt(dx * dx + dy * dy);
        }
    }
    return distanceMatrix;
}

// Function to find the next vertex using the MinMax criterion
int findNextVertexMinMax(int *tour, int tourLength, double **distanceMatrix, int numOfCoords, bool *visited) {
    int nextVertex = -1;
    double minMaxDistance = INT_MAX;

    #pragma omp parallel for
    for (int i = 0; i < numOfCoords; i++) {
        if (!visited[i]) {
            double maxDistance = 0;
            for (int j = 0; j < tourLength; j++) {
                double distance = distanceMatrix[i][tour[j]];
                if (distance > maxDistance) {
                    maxDistance = distance;
                }
            }
            #pragma omp critical
            {
                if (maxDistance < minMaxDistance) {
                    minMaxDistance = maxDistance;
                    nextVertex = i;
                }
            }
        }
    }
    return nextVertex;
}

// Function to find the best insertion position
int findBestInsertionPosition(int *tour, int tourLength, int nextVertex, double **distanceMatrix) {
    int bestPosition = 0;
    double minIncrease = INT_MAX;

    for (int i = 0; i < tourLength; i++) {
        int j = (i + 1) % tourLength;
        double increase = distanceMatrix[tour[i]][nextVertex] + distanceMatrix[nextVertex][tour[j]] - distanceMatrix[tour[i]][tour[j]];
        if (increase < minIncrease) {
            minIncrease = increase;
            bestPosition = i + 1;
        }
    }
    return bestPosition;
}

// Function to read the number of coordinates from the file
int readNumOfCoords(char *fileName) {
    FILE *file = fopen(fileName, "r");
    if (!file) {
        printf("Unable to open file %s\n", fileName);
        exit(1);
    }

    int numOfCoords;
    fscanf(file, "%d", &numOfCoords);
    fclose(file);

    return numOfCoords;
}

// Function to read the coordinates from the file
double **readCoords(char *filename, int numOfCoords) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        printf("Unable to open file %s\n", filename);
        exit(1);
    }

    double **coords = (double **)malloc(numOfCoords * sizeof(double *));
    for (int i = 0; i < numOfCoords; i++) {
        coords[i] = (double *)malloc(2 * sizeof(double));
    }

    fscanf(file, "%d", &numOfCoords); // Skip the first line with the number of coordinates

    for (int i = 0; i < numOfCoords; i++) {
        fscanf(file, "%lf %lf", &coords[i][0], &coords[i][1]);
    }

    fclose(file);

    return coords;
}
