#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include <stdbool.h>


int readNumOfCoords(char *fileName);
double **readCoords(char *filename, int numOfCoords);
void writeTourToFile(int *tour, int tourLength, char *filename);
double **createDistanceMatrix(double **coords, int numOfCoords);
int findNextVertex(int *tour, int tourLength, double **distanceMatrix, int numOfCoords, bool *visited);
int findBestInsertionPosition(int *tour, int tourLength, int nextVertex, double **distanceMatrix);

// Main function
int main() {
    char *inputFile = "ssout4096.dat";
    char *outputFile = "output.txt";


    int numOfCoords = readNumOfCoords(inputFile);
    if (numOfCoords == -1) {
        printf("Error reading the file.\n");
        return 1;
    }
    double **coords = readCoords(inputFile, numOfCoords);

    // Create distance matrix
    double **distanceMatrix = createDistanceMatrix(coords, numOfCoords);

    // Smallest Sum Insertion algorithm
    int *tour = (int *)malloc(numOfCoords * sizeof(int));
    bool *visited = (bool *)malloc(numOfCoords * sizeof(bool));
    for (int i = 0; i < numOfCoords; i++) {
        visited[i] = false;
    }

    // Start with the vertex with the lowest index
    tour[0] = 0;
    visited[0] = true;
    int tourLength = 1;

    while (tourLength < numOfCoords) {
        int nextVertex = findNextVertex(tour, tourLength, distanceMatrix, numOfCoords, visited);
        int bestPosition = findBestInsertionPosition(tour, tourLength, nextVertex, distanceMatrix);


        for (int i = tourLength; i > bestPosition; i--) {
            tour[i] = tour[i - 1];
        }
        tour[bestPosition] = nextVertex;
        visited[nextVertex] = true;
        tourLength++;
    }


    writeTourToFile(tour, tourLength, outputFile);


    for (int i = 0; i < numOfCoords; i++) {
        free(coords[i]);
        free(distanceMatrix[i]);
    }
    free(coords);
    free(distanceMatrix);
    free(tour);
    free(visited);

    return 0;
}


double **createDistanceMatrix(double **coords, int numOfCoords) {
    double **distanceMatrix = (double **)malloc(numOfCoords * sizeof(double *));
    for (int i = 0; i < numOfCoords; i++) {
        distanceMatrix[i] = (double *)malloc(numOfCoords * sizeof(double));
        for (int j = 0; j < numOfCoords; j++) {
            double dx = coords[i][0] - coords[j][0];
            double dy = coords[i][1] - coords[j][1];
            distanceMatrix[i][j] = sqrt(dx * dx + dy * dy);
        }
    }
    return distanceMatrix;
}


int findNextVertex(int *tour, int tourLength, double **distanceMatrix, int numOfCoords, bool *visited) {
    int nextVertex = -1;
    double minIncrease = INT_MAX;

    for (int i = 0; i < numOfCoords; i++) {
        if (!visited[i]) {
            double totalIncrease = 0;
            for (int j = 0; j < tourLength; j++) {
                totalIncrease += distanceMatrix[tour[j]][i];
            }
            if (totalIncrease < minIncrease) {
                minIncrease = totalIncrease;
                nextVertex = i;
            }
        }
    }
    return nextVertex;
}


int findBestInsertionPosition(int *tour, int tourLength, int nextVertex, double **distanceMatrix) {
    int bestPosition = 0;
    double minIncrease = INT_MAX;

    for (int i = 0; i < tourLength; i++) {
        int j = (i + 1) % tourLength;
        double increase = distanceMatrix[tour[i]][nextVertex] + distanceMatrix[nextVertex][tour[j]] - distanceMatrix[tour[i]][tour[j]];
        if (increase < minIncrease) {
            minIncrease = increase;
            bestPosition = i + 1;
        }
    }
    return bestPosition;
}


int readNumOfCoords(char *filename) {
    FILE *file = fopen(filename, "r");
    int numOfCoords = 0;

    if (file == NULL) {
        return -1;
    }

    fscanf(file, "%d", &numOfCoords);

    fclose(file);
    return numOfCoords;
}


double **readCoords(char *filename, int numOfCoords) {
    FILE *file = fopen(filename, "r");
    int i;
    double **coords;

    if (file == NULL) {
        printf("Unable to open file: %s\n", filename);
        return NULL;
    }

    coords = (double **)malloc(numOfCoords * sizeof(double *));
    for (i = 0; i < numOfCoords; i++) {
        coords[i] = (double *)malloc(2 * sizeof(double));
    }

    fscanf(file, "%*d"); // (number of coordinates)

    for (i = 0; i < numOfCoords; i++) {
        fscanf(file, "%lf", &coords[i][0]);
        coords[i][1] = 0; 
    }

    fclose(file);
    return coords;
}


void writeTourToFile(int *tour, int tourLength, char *filename) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Unable to open file: %s\n", filename);
        return;
    }

    for (int i = 0; i < tourLength; i++) {
        fprintf(file, "%d\n", tour[i]);
    }

    fclose(file);
}
