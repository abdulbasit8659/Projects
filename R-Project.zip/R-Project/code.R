# Load necessary libraries
library(tidyverse)
library(tseries)
library(forecast)
library(ggplot2)


# Load the data
#data <- read.csv("D:\New folder\R-Project\Gold (1).csv")

#str(data)

# Convert Dates to Date type
#data$Dates <- as.Date(data$Dates, format="%d/%m/%Y")

#class(data)

#data <- read.csv("D:\\New folder\\R-Project\\Gold (1).csv")

#head(data)

#data$Dates <- as.Date(data$Dates, format="%d/%m/%Y")

#head(data)

# Plot the raw data
#ggplot(data, aes(x=Dates, y=Prices)) + geom_line() + ggtitle("Gold Prices Over Time") + xlab("Date") + ylab("Price")

#summary(data$Prices)

#data_clean <- na.omit(data$Prices)

#data_clean <- na.omit(data)

#data_clean <- data[!is.na(data$Prices), ]

#adf_test <- adf.test(data_clean$Prices)

#print(adf_test)


#data_clean <- data[!is.na(data$Prices), ]

#prices_ts <- ts(data_clean$Prices)

#acf plot
#acf(prices_ts, main="ACF of Gold Prices")


# PACF plot
#pacf(prices_ts, main="PACF of Gold Prices")



# Time plot of the original data
#ggplot(data, aes(x=Dates, y=Prices)) + geom_line() + ggtitle("Time Plot of Non-Stationary Gold Prices") + xlab("Date") + ylab("Price")


# If the data is non-stationary, apply differencing
#diff_prices <- diff(data$Prices)
#data_diff <- data.frame(Dates = data$Dates[-1], Prices = diff_prices)


#Time plot of the differenced data
#ggplot(data_diff, aes(x=Dates, y=Prices)) + geom_line() + ggtitle("Time Plot of Stationary Gold Prices") + xlab("Date") + ylab("Differenced Price")



#summary(diff_prices)

#diff_prices_clean <- na.omit(diff_prices)


#adf_test_diff <- adf.test(diff_prices_clean)
#print(adf_test_diff)


#adf_test_diff <- adf.test(diff_prices_clean)
#print(adf_test_diff)



# Remove missing values from differenced data
#diff_prices_clean <- na.omit(diff_prices)

# Check the length and summary of cleaned differenced data
#length(diff_prices_clean)
#summary(diff_prices_clean)

#Generate ACF and PACF plots
#acf(diff_prices_clean, main="ACF of Differenced Gold Prices")
#pacf(diff_prices_clean, main="PACF of Differenced Gold Prices")


# Perform the ADF test on cleaned differenced data
#library(tseries)  # Ensure the tseries package is loaded
#adf_test_diff <- adf.test(diff_prices_clean)
#print(adf_test_diff)


#library(tidyverse)
#library(forecast)


#Convert Prices to time series object
#gold_ts <- ts(data$Prices, frequency = 365)

# Fit Arima models
#model_1 <- arima(gold_ts, order=c(2,1,3))
#model_2 <- arima(gold_ts, order=c(0,0,1))
#model_3 <- arima(gold_ts, order=c(0,1,1))
#model_4 <- arima(gold_ts, order=c(0,2,1))


# Print summaries of the models
#summary(model_1)
#summary(model_2)
#summary(model_3)
#summary(model_4)

# Calculate AIC and BIC for each model
#aic_values <- c(AIC(model_1), AIC(model_2), AIC(model_3), AIC(model_4))
#bic_values <- c(BIC(model_1), BIC(model_2), BIC(model_3), BIC(model_4))


#model_comparison <- data.frame(
#  Model = c("ARIMA(2,1,3)", "ARIMA(0,0,1)", "ARIMA(0,1,1)", "ARIMA(0,2,1)"),
#  AIC = aic_values,
#  BIC = bic_values
#)

# Print the comparison
#print(model_comparison)





# Load necessary libraries
#library(tseries)
#library(forecast)

#library(ggplot2)
#library(lmtest)

# Load the data
#data <- read.csv("D:/New folder/R-Project/VOL (1).csv")
#head(data)


# Convert Dates to Date type
#data$Years <- as.Date(data$Years, format="%d/%m/%Y")
#head(data)

#adf_test <- adf.test(vol_ts)
#print(adf_test)

# Time series plot
#ggplot(data, aes(x=Years, y=VOL)) + geom_line() + ggtitle("Time Series Plot of VOL") + xlab("Date") + ylab("Volatility")




# Histogram
#hist(data$VOL, main="Histogram of VOL", xlab="Volatility", breaks=30)



# QQ-Plot
#qqnorm(data$VOL, main="QQ-Plot of VOL")
#qqline(data$VOL)


# Load FinTS package for ArchTest
#library(FinTS)

#vol_ts <- ts(data$VOL, frequency = 365)

# Apply the LM ARCH test


# Fit an initial AR model to the data
#ar_model <- ar(vol_ts)

# Apply the LM ARCH test
#arch_test <- ArchTest(residuals(ar_model))
#print(arch_test)


# #Portfolio 5
# # Load necessary libraries
# library(quantmod)
# library(dplyr)
# library(caret)
# library(pROC)
# 
# # Download DAX Index data from Yahoo Finance
# getSymbols("^GDAXI", src = "yahoo", from = "2020-01-01", to = Sys.Date())
# 
# # Prepare the data
# dax_data <- na.omit(GDAXI)
# dax_data <- data.frame(Date = index(dax_data), coredata(dax_data))
# dax_data <- dax_data %>%
#   mutate(Return = (GDAXI.Close - lag(GDAXI.Close)) / lag(GDAXI.Close),
#          Positive_Return = ifelse(Return > 0, 1, 0)) %>%
#   na.omit()
# 
# # Develop a Logistic Regression Model
# # Split the data into training and testing sets
# set.seed(123)
# train_index <- createDataPartition(dax_data$Positive_Return, p = 0.8, list = FALSE)
# train_data <- dax_data[train_index, ]
# test_data <- dax_data[-train_index, ]
# 
# # Develop the logistic regression model
# logistic_model <- glm(Positive_Return ~ GDAXI.Close + GDAXI.Volume, data = train_data, family = binomial)
# 
# # Summary of the model
# summary(logistic_model)



# 
# # Calculate Accuracy and ROC
# # Predict on the test set
# predictions <- predict(logistic_model, newdata = test_data, type = "response")
# predicted_classes <- ifelse(predictions > 0.5, 1, 0)
# 
# # Calculate accuracy
# conf_matrix <- confusionMatrix(as.factor(predicted_classes), as.factor(test_data$Positive_Return))
# accuracy <- conf_matrix$overall['Accuracy']
# print(paste("Accuracy: ", accuracy))
# 
# # Calculate ROC and AUC
# roc_curve <- roc(test_data$Positive_Return, predictions)
# auc <- auc(roc_curve)
# print(paste("AUC: ", auc))
# 
# # Plot ROC curve
# plot(roc_curve, main = "ROC Curve for Logistic Regression Model", col = "blue")




# #Portfolio 6
# 
# # Load necessary libraries
# library(dplyr)
# library(readr)
# 
# # Read the data
# data <- read_csv("D:/New folder/R-Project/CAPM.csv")
# 
# # Convert dates to Date format if necessary
# data$Date <- as.Date(data$Date, format="%d/%m/%Y")
# 
# # Assume S&P 500 (SNP) is the market return, and we'll calculate excess returns
# # Risk-free rate approximation (we'll use USTB6M as a proxy for risk-free rate)
# 
# # Calculate excess returns
# data <- data %>%
#   mutate(Excess_SNP = SNP - USTB6M,
#          Excess_App = App - USTB6M)
# 
# # View the first few rows of the data
# head(data)
# 
# 
# # CAPM: Excess_App = alpha + beta * Excess_SNP + epsilon
# capm_model <- lm(Excess_App ~ Excess_SNP, data = data)
# 
# # Summary of the CAPM model
# summary(capm_model)
# 
# 
# # APT: Excess_App = alpha + beta1 * Mic + beta2 * CC + beta3 * IP + beta4 * CPI + epsilon
# apt_model <- lm(Excess_App ~ Mic + CC + IP + CPI, data = data)
# 
# # Summary of the APT model
# summary(apt_model)




























































































































